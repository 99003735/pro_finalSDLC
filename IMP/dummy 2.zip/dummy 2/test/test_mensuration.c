#include "unity.h"
#include <mensuration.h>

/* Modify these two lines according to the project */
//
#include <mensuration.h>
#define PROJECT_NAME    "Calculator"

/* Prototypes for all the test functions */
void test_area_of_square(void);
void test_area_of_square_testcase2(void);
void test_area_of_circle(void);
void test_area_of_sphere(void);
void test_volume_of_sphere(void);

/* Required by the unity test framework */
void setUp(){}
/* Required by the unity test framework */
void tearDown(){}

/* Start of the application test */
int main()
{
     /* Initiate the Unity Test Framework */
  UNITY_BEGIN();

  /* Run Test functions */
  RUN_TEST(test_area_of_square);
  RUN_TEST(test_area_of_square);
  RUN_TEST(test_area_of_circle);
  RUN_TEST(test_area_of_sphere);
  RUN_TEST(test_volume_of_sphere);

  /* Close the Unity Test Framework */
  return UNITY_END();
}
           

/* Write all the test functions */ 
void test_area_of_square(void) 
{
  TEST_ASSERT_EQUAL(4.00, area_of_square(2));
  TEST_ASSERT_EQUAL(9.00, area_of_square(3));
}
void test_area_of_square_testcase2(void) 
{
 
  /* Dummy fail*/
  //TEST_ASSERT_EQUAL(59.00, area_of_square(7));
}
void test_area_of_circle(void) 
{
  TEST_ASSERT_EQUAL(27.00, area_of_circle(3));
  
  /* Dummy fail*/
  //TEST_ASSERT_EQUAL(30.00, area_of_circle(10));
}

void test_area_of_sphere(void)
 {
  TEST_ASSERT_EQUAL(48.00, area_of_sphere(2));
  
  /* Dummy fail*/
  //TEST_ASSERT_EQUAL(2.00,area_of_sphere(5));
}

void test_volume_of_sphere(void) 
{
  TEST_ASSERT_EQUAL(3.00, volume_of_sphere(1));
  
  /* Dummy fail*/
  //TEST_ASSERT_EQUAL(20.00, volume_of_sphere(2));
}
