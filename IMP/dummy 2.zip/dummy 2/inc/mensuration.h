  
# ifndef __MENSURATION_H_
# define __MENSURATION_H_
//#include <stdio_ext.h>

#include "unity.h"
#include<stdio.h> 
#include<stdlib.h>
//#include <stdio_ext.h>

void mensuration();
double area_of_square(double);
double area_of_circle(double);
double area_of_sphere(double);
double volume_of_sphere(double);



# endif 