#include <mensuration.h>
#include <stdio.h>


void main()
{
    double result = 0;
     int ch;
     double num1 = 0,num2 = 0;
     double AREAOFSQAURE,AREAOFCIRCLE,AREAOFSPHERE,VOLUMEOFSPHERE;
   //do
    //{
       

        printf("\n\n\t\t\t___Mensuration MENU___");
        printf("\n\n1)AREA OF SQUARE ");
        printf("\n\n2)AREA OF CIRCLE ");
        printf("\n\n3)AREA OF SPHERE ");
        printf("\n\n4)VOLUME OF SPHERE ");

        printf("\n\n5)TO RESET THE CALCULATOR");
        printf("\n\nEnter your Choice:");
        scanf(" %d",&ch);
        switch(ch)
        {
            case 1:
                printf("Enter a number: \n");
                scanf(" %lf",&num1);
                result = area_of_square(num1);
                printf("%0.2lf\n",result);
                break;
            case 2:
                printf("\nEnter a number:");
                scanf(" %lf",&num1);
                 result= area_of_circle(num1);
                printf("%0.2lf",result);
                break;

            case 3:
                printf("\nEnter a number:");
                scanf(" %lf",&num1);
                 result= area_of_sphere(num1);
                printf("%0.2lf",result);
                break;
            case 4:
                printf("\nEnter a number:");
                scanf(" %lf",&num1);
                 result= volume_of_sphere(num1);
                printf("%0.2lf",result);
                break;
             //return 0;
              
            default:
                printf("\nWrong Choice");
                break;
 
        }      
 }